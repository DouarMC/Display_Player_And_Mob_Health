import { system, world } from "@minecraft/server";
// Crée ou récupère l'objectif 'players_health'
export const playersHealthObjective = world.scoreboard.getObjective("douarmc:players_health")
    ?? world.scoreboard.addObjective("douarmc:players_health", "PV");
// Supprime les participants si ils ne sont plus dans le monde.
system.runInterval(() => {
    const playerHealthParticipants = playersHealthObjective.getParticipants();
    playerHealthParticipants.forEach((playerHealthParticipant) => {
        try {
            playerHealthParticipant.getEntity();
        }
        catch (e) {
            playersHealthObjective.removeParticipant(playerHealthParticipant);
        }
        ;
    });
});
