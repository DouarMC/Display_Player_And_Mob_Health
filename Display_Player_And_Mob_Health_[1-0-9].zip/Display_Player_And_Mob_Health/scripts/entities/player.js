import { world, system } from "@minecraft/server";
import { playersHealthObjective } from "scoreboards/players_health_objective";
// Affiche le nombre de PV des joueurs en dessous de leur pseudo et change leur score dans l'objectif 'player_health'
system.runInterval(() => {
    const players = world.getAllPlayers();
    players.forEach((player) => {
        const playerHealthComponent = player.getComponent("minecraft:health");
        let playerCurrentHealth = playerHealthComponent.currentValue;
        const playerAbsorptionEffect = player.getEffect("absorption");
        if (playerAbsorptionEffect !== undefined) {
            const playerAbsorptionHealth = 4 * playerAbsorptionEffect.amplifier;
            playerCurrentHealth = playerCurrentHealth + playerAbsorptionHealth;
            player.nameTag = `${player.name}` + "\n" + `[§e${playerCurrentHealth}§f` + "/" + `${playerHealthComponent.effectiveMax}]`;
        }
        else {
            player.nameTag = `${player.name}` + "\n" + `[${playerCurrentHealth}` + "/" + `${playerHealthComponent.effectiveMax}]`;
        }
        ;
        playersHealthObjective.setScore(player, playerCurrentHealth);
    });
});
// Enlève l'affichage des PV du joueur si celui-ci a le tag 'douarmc:hide_player_health'
system.runInterval(() => {
    const players = world.getAllPlayers();
    players.forEach((player) => {
        if (player.hasTag("douarmc:hide_player_health") === false)
            return;
        player.nameTag = player.name;
    });
});
