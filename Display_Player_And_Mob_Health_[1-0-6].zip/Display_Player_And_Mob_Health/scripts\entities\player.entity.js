import { world, system } from "@minecraft/server";
/**
 * Affiche les PV actuelles et maximum en dessous du pseudo des joueurs
 */
export const displayPlayerHealthAsNametag = () => system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        const healthComponent = player.getComponent("minecraft:health");
        player.nameTag = `${player.name}\n[${healthComponent.currentValue}/${healthComponent.effectiveMax}]`;
    });
});
/**
 * Enlève les PV actuelles et maximum en dessous du pseudo des joueurs
 */
export const hidePlayerHealthAsNametag = () => system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        /* CONDITION D'ARRÊT */ if (player.hasTag("douarmc:hide_player_health") === false)
            return;
        player.nameTag = player.name;
    });
});
