import * as ALL_EXPORTS from "exports";
// System Interval
ALL_EXPORTS.displayPlayerHealthAsNametag();
ALL_EXPORTS.hidePlayerHealthAsNametag();
