import { world, system, DisplaySlotId } from "@minecraft/server";
import { Utilities } from "utilities";
//Setup
const healthObjective = world.scoreboard.getObjective("healthObjective")
    ?? world.scoreboard.addObjective("healthObjective", "§c❤");
world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.BelowName, { objective: healthObjective });
//Loop
system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        const healthComp = player.getComponent("minecraft:health");
        healthObjective.setScore(player, healthComp.currentValue);
    });
});
system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        const entity = Utilities.getClosestEntityFromViewDirection(player, 5);
        if (entity === undefined || entity.typeId === "minecraft:player") {
            return player.onScreenDisplay.setActionBar("");
        }
        ;
        if (entity.hasComponent("minecraft:health") === false)
            return;
        const healthComp = entity.getComponent("minecraft:health");
        player.onScreenDisplay.setActionBar(`${healthComp.currentValue} §c❤`);
    });
});
