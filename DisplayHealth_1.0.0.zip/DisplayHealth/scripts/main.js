import { world, system, DisplaySlotId } from "@minecraft/server";
const healthObjective = world.scoreboard.getObjective("healthObjective")
    ?? world.scoreboard.addObjective("healthObjective", "§c❤");
world.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.BelowName, { objective: healthObjective });
system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        const healthComp = player.getComponent("minecraft:health");
        healthObjective.setScore(player, healthComp.currentValue);
    });
});
