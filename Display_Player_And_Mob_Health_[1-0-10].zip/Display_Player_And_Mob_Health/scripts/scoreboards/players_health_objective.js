import { system, world } from "@minecraft/server";
/**
 * Objectif qui permet de suivre la vie des joueurs
 */
export const playersHealthObjective = world.scoreboard.getObjective("douarmc:players_health") ?? world.scoreboard.addObjective("douarmc:players_health", "PV"); // Crée ou récupère l'objectif 'players_health'
// Système qui met à jour les participants de l'objectif 'players_health'
system.runInterval(() => {
    const playerHealthParticipants = playersHealthObjective.getParticipants(); // Récupère les participants de l'objectif 'players_health'
    for (const playerHealthParticipant of playerHealthParticipants) { // Parcours les participants
        try {
            playerHealthParticipant.getEntity(); // Tente de récupérer l'entité du participant
        }
        catch (e) {
            playersHealthObjective.removeParticipant(playerHealthParticipant); // Supprime le participant si il n'existe plus
        }
        ;
    }
    ;
});
