import { system } from "@minecraft/server";
import * as ALL_DATAS from "../../utilities/datas";
// Système qui affiche la santé actuelle des entités qui ont un composant de santé sauf les joueurs.
system.runInterval(() => {
    for (const dimension of ALL_DATAS.allDimensions) { // Pour chaque dimension du monde.
        const entitiesExceptPlayers = dimension.getEntities({ excludeTypes: ["minecraft:player"] }); // Récupère toutes les entités de la dimension sauf les joueurs.
        const entitiesWithHealthComponent = entitiesExceptPlayers.filter(entity => entity.hasComponent("minecraft:health")); // Récupère toutes les entités de la dimension qui ont un composant de santé.
        for (const entity of entitiesWithHealthComponent) { // Pour chaque entité de la dimension qui a un composant de santé.
            const entityHealthComponent = entity.getComponent("minecraft:health"); // Récupère le composant de santé de l'entité.
            let entityCurrentHealth = entityHealthComponent.currentValue; // Récupère la santé actuelle de l'entité.
            const entityAbsorptionEffect = entity.getEffect("absorption"); // Récupère l'effet d'absorption de l'entité.
            let entityCurrentHealthText = undefined; // Déclare une variable pour le texte de la santé actuelle de l'entité.
            if (entityAbsorptionEffect !== undefined) { // Si l'entité a un effet d'absorption, le texte devient jaune.
                const entityAbsorptionHealth = 4 * entityAbsorptionEffect.amplifier; // Calcule la santé d'absorption de l'entité.
                entityCurrentHealth = entityCurrentHealth + entityAbsorptionHealth; // Calcule la santé actuelle de l'entité.
                entityCurrentHealthText = `[§e${entityCurrentHealth}§f`; // Définit le texte de la santé actuelle de l'entité avec la couleur jaune.
            }
            else { // Si l'entité n'a pas d'effet d'absorption.
                entityCurrentHealthText = `[${entityCurrentHealth}`; // Définit le texte de la santé actuelle de l'entité.
            }
            ;
            if (entity.getEffect("minecraft:regeneration") !== undefined) { // Si l'entité a un effet de régénération on met son nombre de pv en rose.
                entityCurrentHealthText = `[§d${entityCurrentHealth}§f`; // Définit le texte de la santé actuelle de l'entité avec la couleur rose
            }
            ;
            if (entity.nameTag === undefined) { // Si l'entité n'a pas de nom affiché.
                entity.nameTag = "" + "\n" + entityCurrentHealthText + "/" + `${entityHealthComponent.effectiveMax}]`; // Définit le nom de l'entité avec le texte de la santé actuelle.
            }
            else if (entity.nameTag.includes("\n") === false) { // Si l'entité a un nom affiché sans retour à la ligne.
                entity.nameTag = entity.nameTag + "\n" + entityCurrentHealthText + "/" + `${entityHealthComponent.effectiveMax}]`; // Ajoute le texte de la santé actuelle au nom de l'entité.
            }
            else if (entity.nameTag.includes("\n") === true) { // Si l'entité a un nom affiché avec retour à la ligne.
                entity.nameTag = entity.nameTag.split("\n")[0] + "\n" + entityCurrentHealthText + "/" + `${entityHealthComponent.effectiveMax}]`; // Remplace le texte de la santé actuelle dans le nom de l'entité.
            }
            ;
        }
        ;
    }
    ;
});
