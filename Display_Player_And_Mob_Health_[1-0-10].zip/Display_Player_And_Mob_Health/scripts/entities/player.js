import { world, system } from "@minecraft/server";
import { playersHealthObjective } from "scoreboards/players_health_objective";
// Système qui affiche la santé actuelle des joueurs.
system.runInterval(() => {
    const players = world.getAllPlayers(); // Récupère tous les joueurs du monde.
    for (const player of players) { // Pour chaque joueur du monde.
        const playerHealthComponent = player.getComponent("minecraft:health"); // Récupère le composant de santé du joueur.
        let playerCurrentHealth = playerHealthComponent.currentValue; // Récupère la santé actuelle du joueur.
        const playerAbsorptionEffect = player.getEffect("absorption"); // Récupère l'effet d'absorption du joueur.
        if (playerAbsorptionEffect !== undefined) { // Si le joueur a un effet d'absorption.
            const playerAbsorptionHealth = 4 + 4 * playerAbsorptionEffect.amplifier; // Calcule la santé d'absorption du joueur.
            playerCurrentHealth = playerCurrentHealth + playerAbsorptionHealth; // Calcule la santé actuelle du joueur.
            player.nameTag = `${player.name}` + "\n" + `[§e${playerCurrentHealth}§f` + "/" + `${playerHealthComponent.effectiveMax}]`; // Définit le nom du joueur avec la santé actuelle en jaune.
        }
        else { // Si le joueur n'a pas d'effet d'absorption.
            player.nameTag = `${player.name}` + "\n" + `[${playerCurrentHealth}` + "/" + `${playerHealthComponent.effectiveMax}]`; // Définit le nom du joueur avec la santé actuelle.
        }
        ;
        if (player.getEffect("regeneration") !== undefined) { // Si le joueur a un effet de régénération on met son nombre de pv en rose.
            player.nameTag = `${player.name}` + "\n" + `[§d${playerCurrentHealth}§f` + "/" + `${playerHealthComponent.effectiveMax}]`; // Définit le nom du joueur avec la santé actuelle en rose
        }
        ;
        playersHealthObjective.setScore(player, playerCurrentHealth); // Définit le score de la santé actuelle du joueur.
    }
    ;
});
// Système qui cache la santé des joueurs qui ont le tag pour cacher leur santé.
system.runInterval(() => {
    const players = world.getAllPlayers(); // Récupère tous les joueurs du monde.
    for (const player of players) { // Pour chaque joueur du monde.
        if (player.hasTag("douarmc:hide_player_health") === false)
            continue; // Si le joueur n'a pas le tag pour cacher sa santé on passe au joueur suivant.
        player.nameTag = player.name; // Cache la santé du joueur.
    }
    ;
});
