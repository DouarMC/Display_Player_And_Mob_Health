import { world } from "@minecraft/server";
/**
 * Toutes les dimensions du monde.
 */
export const allDimensions = [
    world.getDimension("minecraft:overworld"),
    world.getDimension("minecraft:nether"),
    world.getDimension("minecraft:the_end")
];
